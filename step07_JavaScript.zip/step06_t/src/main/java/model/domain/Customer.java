package model.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
//@Getter
@Setter
@ToString
public class Customer {
	private String name;
	private int age;
	
	public String getName() {
		System.out.println("getName() 호출 확인");
		return name;
	}
	public int getAge() {
		return age;
	}
}

/* @FunctionalInterface 학습
 * 
 * * 람다식이란? 
 * 	- 메소드를 직접 구현(정의)하지 않고 하나의 식(expression)으로 표현 하는 것
 * 
 * 1. 람다식 개발을 위한 스펙 개발 방식
 * 2. @FunctionalInterface 할용 방법 이해하기
 * 
 * 3. 람다식을 활용하여 사칙 연삼 메소드로 기능 적용해 보기
 * 
 * interface 개발
 * 사칙연산 식을 interface에 대입
 * interface의 메소드 호출(값 대입)하면서 결과 활용
 * 
 * addition / minus / multiplication / division
 * 
 * interface는 절대 new 로 객체 생성 불가
 * - 스펙 일뿐 
 * - 완벽한 하위 클래스 개발 후에 하위 객체 생성은 가능
 * - 타입으로는 사용 가능
 * - 예 : List<타입> 변수 = new ArrayList<타입>();
 * - List는 interface
 */

package step02.ramdasyntax;

@FunctionalInterface
interface Arithmetic{
	public int calculation(int no1, int no2);
}

public class RambdaSyntax00Use {
	
	public static void main(String [] args) {
		
		// addition
		Arithmetic expression = (no1, no2) -> no1 + no2;
		System.out.println(expression.calculation(2, 5)); 
		
		// ? minus
		expression = (no1, no2) -> no1 - no2;
		System.out.println(expression.calculation(2, 5)); 
		
		expression = (no1, no2) -> no1 * no2;
		System.out.println(expression.calculation(2, 5)); 
		
		expression = (no1, no2) -> no1 / no2;
		System.out.println(expression.calculation(2, 5)); 
	}
}





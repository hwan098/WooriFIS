//미션 ???
/* 
 * 두개의 interface 모두 제시 
 * MessageService 먼저 함
 */

package step02.ramdasyntax;
//람다식을 사용하기 위한 선언형 인터페이스
//메소드 하나만 제시(구현부는 없음, 왜? 개발자가 실시간 로직 생성)
@FunctionalInterface
interface MessageService {
	public abstract void sayMessage(String message);
}


@FunctionalInterface
interface Calculation {
	//4칙 연산 수행후 반환하는 추상 메소드 선언
	public abstract int operation(int v1, int v2);
}


public class RambdaSyntax04Test {
	
	public static void main(String args[]) {
		// 괄호가 표현된 람다식
		/* (message) -> System.out.println(message) : 식 
		 * 식은 있으나 어떤 데이터를 식에 적용할지는 모름
		 * 기준은 MessageService의 단일 메소드가 힌트
		 * 람다식 구성시에는 반드시 인터페이스에 제시된 메소드의 parameter에 맞게 개발
		 * 
		 * public abstract void sayMessage(String message);
		 */
		MessageService message1 = (message) -> System.out.println(message);
//		MessageService message1 = message -> System.out.println(message);
//		message1.sayMessage("람다식 활용하기");
		
		
		// 괄호 없는 람다식
		MessageService message2 = message -> System.out.println(message);
		message2.sayMessage("람다식 이해하기");

		
		//??? 미션 - 사칙연산 하기
		
		
		// 타입 선언한 람다식으로 더하기
		Calculation addition = (int v1, int v2) -> v1 + v2;
		System.out.println("5 + 5 = " + addition.operation(5, 5)); //5 + 5 = 15
		
		System.out.println(addition);
		
		// 타입 선언없는 람다식으로 빼기
		Calculation subtraction = (v1, v2) -> v1 - v2;
		System.out.println("5 - 5 = " + subtraction.operation(5, 5)); //5 - 5 = 0

		// 중괄호와 리턴문 있는 람다식으로 곱하기
		Calculation multiplication = (int v1, int v2) -> {
			return v1 * v2;
		};
		Calculation multiplication2 = (d1, d2) -> d2 * d1;
		System.out.println("5 x 5 = " + multiplication.operation(5, 5)); //5 x 5 = 25

		// 중괄호와 리턴문 없는 람다식으로 나누기
		Calculation division = (int v1, int v2) -> v1 / v2;
		System.out.println("5 / 5 = " + division.operation(5, 5)); //5 / 5 = 1


	}
}







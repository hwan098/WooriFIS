package step02.ramdasyntax;

//step01 - No Parameter
@FunctionalInterface
interface Message1 {
	// 문자열 반환 필수, parameter는 없음
	public String message1();
}

//step02 - single parameter
@FunctionalInterface
interface Message2 {
	public String message2(String message);
}

//step03 - multi parameter
@FunctionalInterface
interface Message3 {
	public int sum(int no1, int no2);
}

public class RambdaSyntax01Basic {

	public static void main(String[] args) {

		// step01 - No Parameter
		Message1 m1 = () -> {
			return "No Parameter";
		};
		System.out.println(m1.message1());

		// return 키워드없이 개발
		Message1 m12 = () -> "No Parameter & return keyword";
		System.out.println(m12.message1());

		/*
		 * {} 와 return 키워드 없이 value로만 표현 interface가 보유한 메소드 호출시 자동 반환
		 * 
		@FunctionalInterface
		interface Message2 {
			public String message2(String message);
		}
		 */
		// ? interface 제시후 미션
		// step02 - single parameter
//		Message2 m2 = (String message) -> {
		Message2 m2 = (message) -> {
			return "안녕 " + message;
		};
		System.out.println(m2.message2("single parameter"));

		// return 키워드 없이 개발
		Message2 m21 = (message) -> "안녕 " + message;
		System.out.println(m21.message2("리턴 키워드 없이 호출"));

		
		/*
		@FunctionalInterface
		interface Message3 {
			public int sum(int no1, int no2);
		}
		 */
		//step03 - multi parameter
		//Message3 m3 = (no1, no2) -> {
		Message3 m3 = (int no1, int no2) -> {
			return no1 + no2;
		};
		System.out.println(m3.sum(10,  20));
		
		//return 키워드 생략 하는 문법
		Message3 m32 = (no1, no2) -> no1+no2;
		System.out.println(m32.sum(100, 200));

	}

}

/* ??? 결과보고 완성하기
 실행 결과

--- 1. 기본 반복문 ---
사과 - 배 - 오렌지 - 포도 - 파인애플 - 토마토 - 

--- 2. 람다식 및 함수 연산 사용 ---
사과
배
오렌지
포도
파인애플
토마토

--- 3. Java 8에서 이중 콜론 연산자 사용 ---
사과
배
오렌지
포도
파인애플
토마토

 */

package step02.ramdasyntax;

import java.util.Arrays;
import java.util.List;

public class RambdaSyntax05Test {

	public static void main(String[] args) {
		/* 배열과 list 사용 주목적
		 * 배열 : 다수의 데이터를 프로그램 상에서 활용 단, 이미 사전에 정해진 데이터 수 명확할때
		 * 	- 메모리 생성 후 데이터 저장, 해당 메모리 수 만큼만 데이터 활용
		 * 
		 * list 주 목적
		 * 	1. 동적 메모리, 데이터 저장수에 배열과 달리 제한이 없음
		 *  2. 배열보다 처리는 속도는 느림
		 *  3. forEach() 사용을 위한 타입으로도 쓰임 
		 */
		String[] fruits = {"사과", "배", "오렌지", "포도", "파인애플", "토마토"};
		
		//배열로 List 타입으로 변환
		List<String> fruits2 =  Arrays.asList(fruits);
		       
		System.out.println("--- 1. 기본 반복문 ---");
		//데이터가 존재하는 수 만큼만 반복해서 하나씩 착출후 사용
		for (String fruit : fruits2) {
		     System.out.print(fruit + " - ");
		}
		  
		System.out.println();  //1번과 2번 문구 사이 단순 new line 적용
		
		//? forEach() 메소드와 lambda식을 활용하여 출력해 보기
		System.out.println("\n--- 2. 람다식 및 함수 연산 사용 ---");
		
		//list API에서 제공하는 함수, 순수 배열에서 forEach() 없음
		fruits2.forEach(fruit -> System.out.println(fruit));
		
		System.out.println("\n--- 3. Java 8에서 이중 콜론 연산자 사용 ---");
		fruits2.forEach(System.out::println);
		
	}

}

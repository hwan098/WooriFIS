/* 학습 내용
 * 1. map을 활용
 * 	고유한 구분자로 데이터 구분해서 저장 및 활용하는 자료 형식 : 자료 구조
 *  mapping의 약어
 *  	key와 value 형식으로 구분
 *  	python에선 map 구조를 dict {key:value, ..}
 *  		
 * 2. 1번 충분히 이해 한 후 Stream API 활용
 */

package step02.ramdasyntax;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

public class RambdaSyntax03forEachMap {

	@Test
	public void m1() {
		//<key, value>
		Map<String, String> map = new HashMap<>();
		map.put("1", "현주엽");
		map.put("2", "신동엽");
		map.put("3", "유재석");
		map.put("4", "이영자");
		map.put("5", "민지");
		map.put("6", "김태균");

		/* key 조차도 모는 상태로 다수의 data가 저장된 Map 객체 받아서 사용하는 방식
		 * key와 value 다 확인 
		 */
		System.out.println("--- 1. classic way, loop a Map ---");
		//데이터 존재하는 수 만큼만 반복
		for (Map.Entry<String, String> entry : map.entrySet()) {
			
			System.out.println("Key : " + entry.getKey() 
							    + " Value : " + entry.getValue());
			
		}

		
		//?
		System.out.println("\n--- 2. Java 8 only, forEach and Lambda ---");
		map.forEach( (k, v) -> System.out.println(k + " " + v) );
	}
}


























// forEach()를 활용

package step02.ramdasyntax;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.core.config.Order;
import org.junit.Test;

public class RambdaSyntax02forEachList {

	// step01 - Normal for loop
//	@Test //static 메소드엔 적용 불가
	public void m1() {
		List<String> items = new ArrayList<>();
		items.add("A");
		items.add("B");
		items.add("C");
		items.add("D");
		items.add("E");

		for (String item : items) {
			System.out.println(item);
		}
	}

	// step02 - forEach Loop a List
	@Test
	public void m2() {
		List<String> list = new ArrayList<String>();
		list.add("A");
		list.add("B");
		list.add("C");

		// \t : 키보드의 tab 키와 같은 간격 의미하는 특수기호
		// \n : 개행(new line) 
		System.out.println("--- 1 ---");
//		list.forEach((item) -> System.out.print(item + "\t"));
		list.forEach(item -> System.out.print(item + "\t"));

		System.err.println();  //단순 개행
		list.forEach(v -> System.out.println(v));
		System.out.println();

		//?
		
		// 메소드 더블콜론 연산자 : 장점 - 코드가 굉장히 간결해짐
		System.out.println("--- 2 :: println 적용 ---");
		list.forEach(System.out::println);
		
		System.out.println();

		// 조건문 반영 - B만 출력
		/* 문자열 비교 - public boolen equals(Object o){}
		 * 	- String 에선 문자열 간의 내용 비교로 재정의 했음
		 * 	if(값.equals("B"){
		 *  } 
		 */
		System.out.println("--- 3. 조건문 반영 ---");
		list.forEach(data -> {
			if(data.equals("B")) {
				System.out.println(data);
			}
		});
		
		/* 파이프라인이란?
		 * 	- 여러개가 연결
		 * 	- 한쪽은 방출만, 반대쪽은 입출만 하는 기능들이 여려개 연결되어 있는 구조 
		 * 
		 * stream이란 파이프라인 구성이라 간주
		 * 
		 * list -> stream 형식으로 변환 -> 각 기능별 메소드를 추가 구성
		 * : 데이터 파이프라인 구성
		 */
		// stream과 filter 적용
		System.out.println("--- 4. 조건문 반영 : Stream and filter ---");
		
//		list.stream().filter(v -> v.contains("B")).forEach(System.out::println);
		
		list.stream().filter(data -> data.contains("B")).forEach(v -> System.out.println(v));
		
	}

}








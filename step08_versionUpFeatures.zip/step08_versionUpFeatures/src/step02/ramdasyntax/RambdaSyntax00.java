/* 학습내용
 * 
 * lambda식 적용전 개발 방식의 일반 코드 
 * 보고 이해하기
 * 
 * *.java에는 가급적 하나의 클래스 또는 하나의 interface 또는 enum으로 개발 권장
 * 학습이해 측명에서 RambdaSyntax00.java에 interface와 class 개발
 * 저장 파일명 : main 메소드가 있는 클래스명으로 저장
 * 			  public도 핵심 저장 클래스명에만 선언
 * 
Java8에서 도입
주 목적 : 언어의 표현력을 높이기
개발시 실시간 동적 기능 간결하게 추가

기능적 인터페이스란?
하나의 추상 메소드만 포함
인터페이스의 의도된 목적 지정
@FunctionalInterface 애노테이션 사용
- 참고 : 미완성 메소드 하나만 있고 @FunctionalInterface 
	생략된 interface는 자동으로 @FunctionalInterface으로 인식
	
	
* interface 활용 방법
* 1. 미완성 메소드를 완벽하게 재정의하는 하위 클래스 개발 필수
* 2. 메소드 재정의 rule
* 	반환타입 메소드명([arguments])는 100% 동일하게 재정의	
	
 */
package step02.ramdasyntax;

@FunctionalInterface
interface Arithmetic0 {
	//연산 가능한 메소드로 재정의 해야 함!!!
	//로직이 없는 메소드는 미완성(추상)
	//컴파일 직후 public abstract int calculation(int v1, int v2);
	public int calculation(int v1, int v2);
}

/* 기본으로 interface를 구현하는 하위 클래스 */
class Arithmetic0Impl implements Arithmetic0{
	public int calculation(int v1, int v2) {
		return v1+v2;
	}
}


public class RambdaSyntax00 {

	public static void main(String[] args) {
		
		System.out.println("*** lambda식 이전 구현 방법 ***");
		
		//interface 구현 및 객체 생성하는 문법을 하나로 처리하는 코드 
		//non-lambda
		/* 
		 * 익명 내부 클래스(익명 inner)
		 class RambdaSyntax00$1 implements Arithmetic0{
		 	public int calculation(int v1, int v2) {
				return v1 + v2;
			}
		 }
		 Arithmetic0 arith = new  RambdaSyntax00$1();
		 와 동일
		 */
		Arithmetic0 arith = new Arithmetic0() {
			public int calculation(int v1, int v2) {
				return v1 + v2;
			}
		};
		
		Arithmetic0 arith2 = new Arithmetic0() {
			public int calculation(int v1, int v2) {
				return v1 - v2;
			}
		};
		
		Arithmetic0 arith3 = new Arithmetic0() {
			public int calculation(int v1, int v2) {
				return v1 * v2;
			}
		};
		
		int result = arith.calculation(10, 20); 
		System.out.println("non-lambda 연산값 : " + result);
		
		
	}
}

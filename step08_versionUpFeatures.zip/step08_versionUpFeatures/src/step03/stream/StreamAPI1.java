/*
Stream API란?

"배열이나 컬렉션(list, map..)"처럼 다수의 데이터 그룹을 간단하고 효율적으로 처리할 수 있도록 JDK 8부터 지원(내부 반복)
	- 사용하는 개발자들은 반복 실제 코드는 은닉된 상태로 API호출로 사용
데이터베이스와 같은 연산 수행 가능

스트림 데이터의 특징
- 처리 과정에서 임시로 존재(스트림에 요소(데이터)가 저장되지 않음)
- 배열 또는 IO와 같은 소스의 요소를 계산 작업의 파이프라인을 통해 전달
- 작업 후 자동 소멸(연산시 사용했던 메모리 관리를 자동으로 해준다)
	: 메소드 호출로 처리
데이터 소스 원본의 변경 없이 데이터 처리 작업 수행
 */
package step03.stream;

import java.util.Arrays;
import java.util.List;

public class StreamAPI1 {

	public static void main(String[] args) {
		System.out.println("--- step01 : 다수의 문자열 값들 반복해서 출력 ---");
		List<String> datas = Arrays.asList("일", "이", "삼", "사");

		// for each 반복문으로 직접 출력해 보기
		for(String v : datas) {
			System.out.println(v);
		}

		datas.forEach(v -> System.out.println(v));
		datas.forEach(System.out::println);
		
		// Stream API + 람다식 사용해서 출력해 보기
		System.out.println("--- step02 : 다수의 int 값들 반복해서 출력 ");

		List<Integer> intDatas = Arrays.asList(1, 2, 3, 4, 5);
		//? 람다식 활용해서 forEach메소드 활용
		intDatas.forEach(v -> System.out.println(v));
		intDatas.forEach(System.out::println);
		
	}

}

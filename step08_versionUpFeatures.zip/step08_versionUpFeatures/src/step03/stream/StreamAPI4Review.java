/* review
 * 
 * printf() : 하나의 문자열 내에 특수 기호 사용해서 동적 문자열과 숫자 결합 가능하게 하는 메소드
 * 	- %s : 가변적인 문자열
 *  - %d : 가변적인 숫자값
 *  
 *  System.out.printf("리스트의 모든 문자열 :  %s, 빈문자열 개수 : %d개", strList, count);
 *  - 리스트의 모든 문자열 :  [abc, , bcd, , defg, jk], 빈문자열 개수 : 2개
 *  
 *  - printf 사용전 print()/println() 사용시의 문법
 *  System.out.print("리스트의 모든 문자열 : "+ list변수 + ", 빈문자열 개수 : " + count변수 + "개");
 *  
 *  
 */

package step03.stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.stream.Collectors;

import model.domain.Employee;

public class StreamAPI4Review {

	public static void main(String[] args) {
		System.out.println("-- 1 --");
		List<String> strList = Arrays.asList("abc", "", "bcd", "", "defg", "jk");
		long count = strList.stream().filter(x -> x.isEmpty()).count();
		System.out.printf("리스트의 모든 문자열 :  %s, 빈문자열 개수 : %d개", strList, count);
		
		//따라해보기
		List<String> strList1 = Arrays.asList("abcd", "", "123456789", "", "ll", "aha");
		long count1 = strList1.stream().filter(x -> x.isEmpty()).count();
		System.out.println();
		System.out.printf("리스트의 모든 문자열1 : %s, 빈문자열 개수 : %d개", strList1, count1);
		
		System.out.println("\n-- 2 --");
		long num = strList.stream().filter(x -> x.length() > 3).count();
		System.out.printf("리스트의 문자열 길이가 3이상인 문자열 개수 :  %s, %d개", strList, num);
		
		//따라해보기
		long num1 = strList1.stream().filter(x -> x.length() > 3).count(); 
		System.out.println();
		System.out.printf("리스트1의 문자열 길이가 3이상인 문자열 개수 :  %s, %d개", strList1, num1);
		
		System.out.println("\n-- 3 --");
		count = strList.stream().filter(x -> x.startsWith("a")).count();
		System.out.printf("리스트에서 a로 시작하는 문자들 :  %s,  %d개", strList, count);
		
		//따라해보기
		count1 = strList1.stream().filter(x -> x.startsWith("a")).count();
		System.out.println();
		System.out.printf("리스트1에서 a로 시작하는 문자들 :  %s,  %d개", strList1, count1);
		
		System.out.println("\n-- 4 --");
		List<String> filtered = strList.stream().filter(x -> !x.isEmpty()).collect(Collectors.toList());
		System.out.printf("모든 리스트 데이터 : %s, 빈문자열이 없는 리스트 : %s", strList, filtered);
		
		//따라해보기
		List<String> filtered1 = strList.stream().filter(x -> !x.isEmpty()).collect(Collectors.toList());
		System.out.println();
		System.out.printf("모든 리스트1 데이터 : %s, 빈문자열이 없는 리스트1 : %s", strList1, filtered1);
		
		System.out.println("\n-- 5 --");
		filtered = strList.stream().filter(x -> x.length() > 2).collect(Collectors.toList());
		System.out.printf("모든 리스트 데이터 : %s, 문자열 길이가 2를 초과한 문자열 : %s", strList, filtered);
		
		System.out.println("\n-- 6 --");
		List<String> G7 = Arrays.asList("Korea", "USA", "France", "Germany", "Italy", "U.K.", "Canada");
		String G7Countries = G7.stream().map(x -> x.toUpperCase()).collect(Collectors.joining(", "));
		System.out.println("모든 나라 이름이 대문자로 변환된 데이터 " + G7Countries);
		
		//따라해보기
		String G7Countries1 = G7.stream().map(x -> x.toUpperCase()).collect(Collectors.joining("와"
				+ " "));
		System.out.println("모든 나라 이름이 대문자로 변환된 데이터 " + G7Countries1);
		
		System.out.println("\n-- 7 --");
		List<Integer> numbers = Arrays.asList(9, 10, 3, 4, 7, 3, 4);
		List<Integer> distinct = numbers.stream().map(i -> i * i).distinct().collect(Collectors.toList());
		System.out.printf("모든 데이터 : %s, 곱한 연산 결과값들 중복 제거된 데이터 : %s", numbers, distinct);
		
		//따라해보기
		List<Integer> numbers1 = Arrays.asList(7, 5, 8, 1, 5, 4, 7);
		List<Integer> distinct1 = numbers1.stream().map(i -> i * i).distinct().collect(Collectors.toList());
		System.out.println();
		System.out.printf("모든 데이터 : %s, 곱한 연산 결과값들 중복 제거된 데이터 : %s", numbers1, distinct1);
		
		List<Integer> data = numbers.stream().map(i -> i*i).collect(Collectors.toList());
		System.out.printf("\n--- distince() 없이 %s - %s %n", numbers, data);
		
		//따라해보기
		List<Integer> data1 = numbers1.stream().map(i -> i*i).collect(Collectors.toList());
		System.out.printf("\n--- distince() 없이 %s - %s %n", numbers1, data1);
		
		
		System.out.println("\n-- 8 --");
		List<Integer> primes = Arrays.asList(2, 3, 5, 7, 11, 13, 17, 19, 23, 29);
		IntSummaryStatistics stats = primes.stream().mapToInt((x) -> x).summaryStatistics();
		System.out.println(stats); 
		System.out.println("목록에서 가장 높은 소수 : " + stats.getMax());
		System.out.println("목록에서 가장 작은 소수 : " + stats.getMin());
		System.out.println("모든 수의 합 : " + stats.getSum());
		System.out.println("모든 수의 평균 : " + stats.getAverage());
		
		//? employee 직원들의 최고령 직원, 최소연령 직원, 나이평균, 총 나이의 합 구하기
		List<Employee> peoples = new ArrayList<>();
		
		peoples.add(new Employee(101, "Victor", 23));
		peoples.add(new Employee(102, "Rick", 21));
		peoples.add(new Employee(103, "Sam", 25));
		peoples.add(new Employee(104, "John", 27));
		peoples.add(new Employee(105, "Grover", 23));
		peoples.add(new Employee(106, "Adam", 22));
		peoples.add(new Employee(107, "Samy", 25));  
		peoples.add(new Employee(108, "Duke", 29));
		
		
		IntSummaryStatistics employeeAge = peoples.stream().mapToInt(a -> a.getAge()).summaryStatistics();
		System.out.println(employeeAge);
		System.out.println("최고령 직원 : " + employeeAge.getMax());
		System.out.println("최소연령 직원 : " + employeeAge.getMin());
		System.out.println("총 나이의 합 : " + employeeAge.getSum());
		System.out.println("나이평균 : " + Math.round(employeeAge.getAverage()));

	}

}
//??? 미션
/* 출력 결과
1. 직원들 평균 나이 : 49.25
2. 이상치를 제외한 직원들 평균 나이 : 24.285714285714285
 */
package step03.stream;

import java.util.ArrayList;
import java.util.List;
	
import model.domain.Employee;

public class StreamAPI3Emp {

	public static void main(String[] args) {
		List<Employee> peoples = new ArrayList<>();
		//사번, 이름 나이
		peoples.add(new Employee(101, "Victor", 23));
		peoples.add(new Employee(102, "Rick", 21));
		peoples.add(new Employee(103, "Sam", 25));
		peoples.add(new Employee(104, "John", 27));
		peoples.add(new Employee(105, "Grover", 23));
		peoples.add(new Employee(106, "Adam", 22));
		peoples.add(new Employee(107, "Samy", 224));  // age가 이상치
		peoples.add(new Employee(108, "Duke", 29));
		
		//? 나이값들 평균 단 출력되는 데이터는 double타입으로 반환 및 출력
		/* mapToInt(e -> e.getAge())
		 * - e : List에서 하나씩 뽑은 Employee 객체
		 * - mapToInt() : int값들 취합해서 intStream 구조로 반환
		 */
		double avgAge = peoples.stream().mapToInt(e -> e.getAge()).average().getAsDouble();
		System.out.println(avgAge);  //49.25
		
		//? 이상치를 제거하고 평균구하기
		avgAge = peoples.stream().mapToInt(e -> e.getAge()).filter(age -> age < 200).average().getAsDouble();
		System.out.println(avgAge); 
		
		/* 한단 코드의 단점
		 * 	filter() 의  parameter도 Employee 받음
		 *  mapToInt() 의  parameter도 Employee 받음
		 *  즉 어차피 age 값은 한번만 착출하는게 좋음 따라서 mapToInt().filter() 순으로 작업 권장
		 */
		avgAge = peoples.stream().filter(e -> e.getAge() < 200).mapToInt(e -> e.getAge()).average().getAsDouble();
		System.out.println(avgAge); 

	}
}






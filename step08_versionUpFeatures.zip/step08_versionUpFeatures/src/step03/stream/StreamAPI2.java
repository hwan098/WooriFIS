/* Stream의 다양한 API 활용하기 
 * 처리 단계
 * Stream 생성 -> Stream 중개 연산 : 파이프 필터 패턴 적용 -> Stream 최종 연산
 */
package step03.stream;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamAPI2 {

	public static void main(String[] args) {
		List<Integer> intDatas = Arrays.asList(1, 2, 3, 4, 5);

		// 보고 이해하기

		/*
		 * mapToInt() 각 요소를 int로 매핑하여, int 요소를 모은 IntStream을 반환 후 다양한 유용한 메서드를 사용
		 * - sum(), max(), min(), average(), count() 등을 사용하여 각각의 연산을 수행
		 */

		//문자열들, 숫자 연산이 부적합한 타입
		//연산시에는 반드시 숫자로 변환해서 연산
		/*
		 * java.lang.Integer의 public static int parseInt(String v){}
		 * java.lang.Double의 public static double parseDouble(String v){}
		 * 
		 * ::
		 * 1. System.out.println(출력데이터) -> System.out::println
		 * 2. Integer.parseInt("값") - Integer::parseInt
		 */
		List<String> values = Arrays.asList("1", "2", "3", "4", "5");
		int sum = values.stream().mapToInt(Integer::parseInt).sum();
		System.out.println("합: " + sum); //합: 15

		int sumResult = 0;
		for(String v : values) {
//			sumResult = sumResult + Integer.parseInt(v);
			sumResult += Integer.parseInt(v);
		}
		
		System.out.println("----- " + sumResult); // 15
		
		//문자열들을 double 타입으로 변환해서 합 구하는 로직
		System.out.println(values.stream().mapToDouble(Double::parseDouble).sum());//15.0
		
				
		
		//[2, 4]
		/* v -> v % 2 == 0
		 * 	v % 2 
		 * 		v % 2 == 0
		 */
		//유입되는 데이터의 짝수들만 filtering해서 하나의 배열 또는 list형식으로 반환
		/* Stream map() : filtering된 데이터를 Stream 객체로 변화해서 다음 단계로 이동		
		 * List<Integer> collect() : 방출된 데이터들을 수집해서 하나의 list형식으로 반환
		 * 
		 * Collectors.toList() : Stream에서 방출된 모든 데이터로 새로운 List객체를 생성하는 메소드
		 * collect() : Stream 데이터들 새로운 collection 타입으로 변환하는 메소드
		 * forEach() : Stream 이 보유한 다수의 데이터들에 대해 parameter로 제시된 일관된 로직으로 데이터 처리
		 * 
		 * 메소드의 반환 타입 확인 하기 위한 예제
		 */
		
		//??? 동일한 결과를 다른 각도에서 개발 가능한지 확인???
		
		System.out.println(intDatas.stream().filter(v -> v % 2 == 0).collect(Collectors.toList()));
		System.out.println("---- " + Collectors.toList()); //java.util.stream.Collectors$CollectorImpl@31b7dea0
		
		System.out.println("***");  
		//List<Integer> intDatas = Arrays.asList(1, 2, 3, 4, 5);
		intDatas.stream().filter(v -> v % 2 == 0).collect(Collectors.toList()).forEach(System.out::println);

		/*
		 * mapToInt() 각 요소를 int로 매핑하여, int 요소를 모은 IntStream을 반환 후 다양한 유용한 메서드를 사용
		 * - sum(), max(), min(), average(), count() 등을 사용하여 각각의 연산을 수행
		 * 
		 * Stream API : sum()은 없음 따라서 mapToInt()로 sum()  보유한 IntStream  객체 반환
		 * 
		 * IntStream API : sum() 등과 같이 숫자로 처리하는 서비스 기능을 제공
		 */

		// ?
		System.out.println("--- step01 :  짝수값만 받아서 합 ");
		System.out.println(intDatas.stream().filter(v -> v%2 == 0));//java.util.stream.ReferencePipeline$2@22a71081
		System.out.println(intDatas.stream().filter(v -> v%2 == 0).count());
	
		System.out.println(intDatas.stream().filter(v -> v%2 == 0).mapToInt(v -> v).max()); //OptionalInt[4]
		
		System.out.println(intDatas.stream().filter(v -> v%2 == 0).mapToInt(v -> v).max().getAsInt()); //4
	
		System.out.println(intDatas.stream().filter(v -> v%2 == 0).mapToInt(v -> v).sum());//java.util.stream.ReferencePipeline$2@22a71081

		
		//List<Integer> intDatas = Arrays.asList(1, 2, 3, 4, 5);
		System.out.println("--- step02 :  홀수값만 합 구하기 ");
		System.out.println(intDatas.stream().filter(v -> v%2 != 0).mapToInt(v -> v).sum()); //9

		System.out.println("--- step03 :  홀수 개수 출력하기  ");
		System.out.println(intDatas.stream().filter(v -> v%2 != 0).mapToInt(v -> v).count()); //3
		

		System.out.println("--- step04 :  홀수중 최대값(max) 출력하기  ");
		System.out.println(intDatas.stream().filter(v -> v%2 != 0).mapToInt(v -> v).max().getAsInt());
		
		

		//List<Integer> intDatas = Arrays.asList(1, 2, 3, 4, 5);
		// skip() / forEach()
		System.out.println("--- step05 :   2만 빼고 출력하기  ");
		intDatas.stream().filter(v -> v != 2).forEach(System.out::println);
		
		//List<Integer> intDatas = Arrays.asList(1, 2, 3, 4, 5);
		System.out.println("--- step06 :  skip(int index) : 지정한 데이터의 순번까지는 skip하고 출력");
		intDatas.stream().skip(2).forEach(System.out::println);  // 3, 4, 5

	}

}









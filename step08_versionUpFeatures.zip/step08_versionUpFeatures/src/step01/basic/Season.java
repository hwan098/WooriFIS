package step01.basic;

public enum Season {
	봄, 여름, 가을, 겨울
}

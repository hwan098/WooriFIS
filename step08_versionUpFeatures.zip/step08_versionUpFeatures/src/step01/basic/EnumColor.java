/* Enum이란?
 * 고정된 상수 집합을 포함하는 데이터 유형
 * 유형의 안정성 향상
 * 
 * 허용 가능한 값들만으로 제한 할 수 있음(명확성, 데이터의 정확성)
 * 내용의 추가가 필요 하더라도, enum 외에 수정할 필요가 없음
 * 리펙토링시 변경 범위가 최소화
 * 
 * 
 */

package step01.basic;

/* 데이터로 색을 문자열로 표현해야 할 경우
 * 고려사항 - 어떤 색을 표현? 부적합한 표현은 어떻게 제거할 것인가?
 * 		  - 대소문자?, 사용하는 코드에선 실수가 없게 하려면(제대로 호출? 값 변경 불가!!!)..
 * 
 * public class EnumColor {
	pubilc final int RED = 1;
	pubilc final int YELLOW = 2;
	BLUE
   }
 * 
 */

//개발자가 개발하지 않아도 데이터 사용 가능한 일부 메소드들이 제공
public enum EnumColor {
	RED, YELLOW, BLUE, GREEN
}




/* 학습 내용
 * - forEach() / lambda식 / double 연산자 코드이해하기
 * 
 * - 람다
 * 	: python, js, java, ...
 * 	: 동적으로 로직을 수정할수 있는 기술
 * 		사칙연산 로직 : 4개의 메소드로 개발이 기본이었으나 람다식 활용시에는 선언 후 실시간 개발하면서 다양한 연산식 연출 가능
 * 		람다식 - 표현식이 대입된 문법 활용 		
 */
package step01.basic;

import java.util.Arrays;
import java.util.List;

import model.domain.People;

public class DoubleColonForEachLamba {

	public static void main(String[] args) {
		
		//사용하고자 하는 test 데이터
		People p1 = new People("박나래", 30);
		People p2 = new People("유재석", 40);
		People p3 = new People("현주엽", 50);
		
		//다수의 데이터로 하나의 List로 취합해서 반환
		List<People> peoples = Arrays.asList(p1, p2, p3);
		
		/* List<People> peoples = new ArrayList<People>();
		 * peoples.add(p1);
		 * peoples.add(p2);
		 * peoples.add(p3);
		 */
		
		System.out.println("--- step01 : 기본 for문 ---");
		for(People p : peoples) {
			System.out.println(p);
		}
		
		/* peoples 변수는 People 객체들을 보유한 list
		 * peoples. 으로 반복해서 데이터 하나씩 뽑아서 p라는 변수에 대입후 
		 * 람다식 -> 으로 오른쪽 문장에 p값 제공
		 */
		System.out.println("\n--- step02 : random식 ---");
		peoples.forEach(p -> System.out.println(p));
		
		
		//peoples 가 보유한 개별 데이터이 존재하는 횟수 만큼 출력
		System.out.println("\n--- step03 : double colon ---");
		peoples.forEach(System.out::println);
		
		
		System.out.println("\n--- step04 : double colon ---");
		Arrays.asList(p1, p2, p3).forEach(System.out::println);

		
	}

}

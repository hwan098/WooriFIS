package step01.basic;

public class EnumUseTest {

	public static void main(String[] args) {
		
		System.out.println(EnumColor.RED); //RED
		
		System.out.println("*** 반복문을 활용한 데이터 출력 ***");
		
		//열거 상수 목록을 Color[] 형태로 반환
		//RED	YELLOW	BLUE 순으로 출력
		EnumColor[] colors = EnumColor.values();
		
		for(EnumColor v : colors) {
			System.out.println(v);
		}
		
		
		//? 계절 
		//모든 계절 데이터 출력 
		Season [] s = Season.values();
		
		for(Season v : s) {
			System.out.println(v);
		}
	}

}





package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/validation")
public class LoginCheck extends HttpServlet {

	// 공통된 처리 로지그이 별도의 사용자 정의 메소드 : 만들고 직접 코드로 호출
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		// 데이터 획득
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");

		// 조건 비교
		if (id.equals("master") && pw.equals("77")) {
			HttpSession session = request.getSession();//세션 생성
			session.setAttribute("name", "재석");//세션에 데이터 저장
			response.sendRedirect("welcome");
		} else {
			request.setAttribute("errorMsg", "무효한 id/pw입니다");
			request.getRequestDispatcher("fail").forward(request, response);
		}
	}
}









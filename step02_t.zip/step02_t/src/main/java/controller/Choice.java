package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Choice
 */
@WebServlet("/choice")
public class Choice extends HttpServlet {

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println(request.getMethod());
//		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("UTF-8");
		String[] value = request.getParameterValues("season");
//		for(String x : value) {
//			System.out.println(x);
//		}
		
		System.out.println(value);
		
		if(value != null && value.length > 0) {
			String valueToString = String.join(", ", value);
			
			//String script = "<script>alert('선택한 계절은: " + valueToString + "');</script>";
			request.setAttribute("message", valueToString);
			System.out.println(request.getAttribute("message"));
			System.out.println("value값 들어옴");
		}
		else {
			request.setAttribute("message", "선택한 계절이 없습니다.");
			response.sendRedirect("index.jsp");
		}
		request.getRequestDispatcher("index.jsp").forward(request, response);
		
		
	}

}

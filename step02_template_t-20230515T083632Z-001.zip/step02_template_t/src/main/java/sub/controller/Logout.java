package sub.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/logout")
public class Logout extends HttpServlet {
     
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		session.invalidate();
		session = null;
		/* 로그아웃 확인을 위한 팝업창(경고창, 모달) 적용을 위해 jsp 개발
		 * index.html에 js는 시작 화면(경고창 실행되면 안되는 화면)
		 * 로그아웃시 팝업창이 필요해서 동일한 화면에 새로운 jsp로 개발
		 * - 다양한 자바 데이터 출력도 가능한 jsp 파일
		 */
		response.sendRedirect("index.jsp");
	}

}

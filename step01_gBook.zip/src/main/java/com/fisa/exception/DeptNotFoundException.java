package com.fisa.exception;

public class DeptNotFoundException extends Exception{
	public DeptNotFoundException() {}
	public DeptNotFoundException(String m) {
		super(m);
	}

}
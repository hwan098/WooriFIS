package com.fisa.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fisa.exception.DeptNotFoundException;
import com.fisa.model.dao.DeptCopyRepository;
import com.fisa.model.domain.entity.DeptCopy;

@RestController
public class DeptCopyController {
	
	
	//DAO를 멤버로 선언 및 자동 초기화
	@Autowired
	private DeptCopyRepository dao;
	
	//특정 부서 번호로 검색
	@GetMapping("/deptone")
	public DeptCopy getDept(int deptno) throws Exception {
		System.out.println("deptno : " + deptno);
		//System.out.println("dao.findById(deptno) : " + dao.findById(deptno));
		
		Optional<DeptCopy> dept = dao.findById(deptno);
		System.out.println("dept : " + dept);
		
		//deptno가 없는 번호일 때-> 데이터가 없을 때
		dept.ifPresentOrElse(System.out::println, () -> System.out.println("데이터 무"));
		
		//client에게 상태 보고 로직
		//데이터가 없을 때 error.jsp 등으로 일괄 메시지 위임해 예외 발생을 유도
		dept.orElseThrow(Exception::new); //데이터 null인경우 예외 생성 및 메소드 현 라인에서 실행중지
		//? 검색된 데이터 반환
		//return dao.findById(deptno).get(); 기존코드이고 밑에 코드가 Optional<DeptCopy> dept = dao.findById(deptno);이용했기 때문에 dept.get()가능
		return dept.get();
	}
	
	//모든 검색
	@GetMapping("deptall")
	public Iterable<DeptCopy> getDeptAll(){
		return dao.findAll();
		
	}
	
	//특정 부서 번호로 삭제
	@GetMapping("deptdelete")
	public Iterable<DeptCopy> delete(int deptno) throws DeptNotFoundException{
		DeptCopy dept = dao.findById(deptno).orElseThrow(DeptNotFoundException::new);
		dao.deleteById(deptno);
		//dept.ifPresentOrElse(System.out::println, () -> System.out.println("없는 데이터"));
		//dept.orElseThrow(DeptNotFoundException::new);
		return dao.findAll();
		
	}
	//예외 전담 처리 메소드
	@ExceptionHandler
	public String exHandler(Exception e) {
		e.printStackTrace();
		return "요청 시 입력 데이터 재확인 부탁드립니다.";
	}
	@ExceptionHandler(DeptNotFoundException.class)
	public String exHandler(DeptNotFoundException e) {
		e.printStackTrace();
		return "해당 부서 번호는 존재하지 않습니다.";
	}

}

/* 이미 존재하는 테이블 사용하는 로직으로 spring data 학습
 * 테이블 명 : deptcopy
 * yml의 테이블 생성 비활성화 : none
 * 
 * */

package com.fisa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Step01GBookApplication {

	public static void main(String[] args) {
		SpringApplication.run(Step01GBookApplication.class, args);
	}

}

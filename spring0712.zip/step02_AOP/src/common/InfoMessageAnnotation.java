package common;

import java.sql.SQLException;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class InfoMessageAnnotation {

    @Before("execution(* step03.aop.biz.Car.buy*())")
    public void beforeBiz() {
        System.out.println("��: ���� �Ͻǰǰ���?");
        //...
    }

    @After("execution(* step03.aop.biz.Car.buy*())")
    public void afterBiz() {
        System.out.println("��: ���� �Ϸ�Ǿ����ϴ�.");
        //...
    }

    @AfterReturning(pointcut = "execution(* step03.aop.biz.Car.buy*())", returning = "bizReturnData")
    public void returnPrint(String bizReturnData) {
        System.out.println("biz �޼ҵ� ��ȯ �����͸� ���� �ڵ忡�� ����: " + bizReturnData);
    }

    @AfterThrowing(pointcut = "execution(* step03.aop.biz.Car.exceptionTest())", throwing = "e")
    public void exceptionFilter(NullPointerException e) {
        System.out.println("NullPointerException �߻� �ÿ��� ó��");
    }

    @AfterThrowing(pointcut = "execution(* step03.aop.biz.Car.exceptionTest())", throwing = "e")
    public void exceptionFilter2(SQLException e) {
        System.out.println("SQLException �߻� �ÿ��� ó��");
    }
}

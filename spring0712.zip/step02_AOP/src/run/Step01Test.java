package run;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import step01.nonaop.biz.Car;

public class Step01Test {

	public static void main(String[] args) {
		ApplicationContext container = new ClassPathXmlApplicationContext("fisa1nonaop.xml");
		Car car = container.getBean("car", Car.class);
		car.buy();
		System.out.println("/*/*/*/*/*/*/*//*/*/*/*");
		car.buy2();
	}

}

package run;

import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import step02.aop.biz.Car;

public class Step02Test {

	public static void main(String[] args) {
		ApplicationContext container = new ClassPathXmlApplicationContext("fisa2aop.xml");
		Car car = container.getBean("biz", Car.class);
		car.buy();
		System.out.println("/*/*/*/*/*/*/*/*/*/*/*");
		car.buy2();
		
		System.out.println("/*/*/*��ȯ�ϴ� biz �޼ҵ� ȣ��/*/*/*");
		car.getMessage();
		
		System.out.println("/*/*/*���� �߻� �� ���� ���� ó��/*/*/*");
		try{
			car.exceptionTest();
		} catch(SQLException e) {
			//e.printStackTrace();
		}
	}

}

package step01;
public class Car {
	private String carName;
	private Engine engine; //has a �����̳� Car�� Engine�� ��������
	
	public Car() {
		System.out.println("Car �⺻ ������");
	}
	public Car(String carName, Engine engine) {
		super();
		this.carName = carName;
		this.engine = engine;
		System.out.println("Car ������");
	}
	
	public String getCarName() {
		return carName;
	}
	public void setCarName(String carName) {
		this.carName = carName;
		System.out.println("Car setCarName()");
	}
	public Engine getEngine() {
		return engine;
	}
	public void setEngine(Engine engine) {
		this.engine = engine;
		System.out.println("Car setEngine()");
	}
	
	
}
package step01;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Step01Test {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("fisa.xml");
		Car c = context.getBean("c", Car.class);
	}

}

package step04;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Step04Test {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("fisa4annotation.xml");
		
		System.out.println(context.getBean("car", Car.class));
		System.out.println(context.getBean("car", Car.class).getEngine());
		
	}

}

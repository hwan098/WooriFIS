package step04;

public class Engine {
	private String engineCompany;
	private int cc;
	
	public Engine(String engineCompany, int cc) {
		this.engineCompany = engineCompany;
		this.cc = cc;
		System.out.println("Engine�� ������");
	}
	
	public Engine() {
		System.out.println("Engine�� ������");
	}

	public String getEngineCompany() {
		return engineCompany;
	}
	public void setEngineCompany(String engineCompany) {
		this.engineCompany = engineCompany;
		System.out.println("Engine�� engineCompany()");
	}
	public int getCc() {
		return cc;
	}
	public void setCc(int cc) {
		this.cc = cc;
	}
	
	
}

package step03.mission;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Step03Test {

    public static void main(String[] args) {
    	ApplicationContext context = new ClassPathXmlApplicationContext("fisa3.xml");
        List<Player> players = new ArrayList<>();
        
        players.add(new Player("나바스", 1));
        players.add(new Player("하키미", 2));
        players.add(new Player("킴펨베", 3));
        players.add(new Player("마르퀴뇨스", 5));
        players.add(new Player("베라티", 6));
        players.add(new Player("음바페", 7));
        players.add(new Player("파비안", 8));
        players.add(new Player("이카르디", 9));
        players.add(new Player("네이마르", 10));
        players.add(new Player("이강인", 19));
        players.add(new Player("슈크리니아르", 37));

        Team team = new Team("psg", players);
        System.out.println();
        
        System.out.println("⚽⚽⚽⚽⚽" + team.getName() + "의 선수 정보" + "⚽⚽⚽⚽⚽");
        for (Player player : team.getPlayer()) {
            System.out.println("이름: " + player.getName() + ", 등번호: " + player.getBackNumber());
        }

    }
}
package step03.mission;

public class Player {
	private String name;
	private int backNumber;
	
	public Player() {
		System.out.println("�⺻Player() ����");
	}

	public Player(String name, int backNumber) {
		super();
		this.name = name;
		this.backNumber = backNumber;
		System.out.println("Player() ����");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getBackNumber() {
		return backNumber;
	}

	public void setBackNumber(int backNumber) {
		this.backNumber = backNumber;
	}
	
	
}

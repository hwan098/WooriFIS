package step03.mission;

import java.util.List;

public class Team {
	private String name;
	private List<Player> player;
	
	public Team() {
	}

	public Team(String name, List<Player> player) {
		this.name = name;
		this.player = player;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Player> getPlayer() {
		return player;
	}

	public void setPlayer(List<Player> player) {
		this.player = player;
	}
	
}
